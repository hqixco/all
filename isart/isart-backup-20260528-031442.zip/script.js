const menuBtn = document.querySelector(".menu-btn");
const nav = document.querySelector(".nav");
const revealItems = document.querySelectorAll(".reveal");
const yearNodes = document.querySelectorAll("[data-year]");
const accordionItems = document.querySelectorAll(".accordion-item");
const quizSteps = document.querySelector("[data-quiz-steps]");
const quizInfo = document.querySelector("[data-quiz-info]");
const quizTitle = document.querySelector("[data-quiz-title]");
const quizDescription = document.querySelector("[data-quiz-description]");
const quizOptions = document.querySelector("[data-quiz-options]");
const quizFinalForm = document.querySelector("[data-quiz-final-form]");
const quizBackButton = document.querySelector("[data-quiz-back]");
const quizNextButton = document.querySelector("[data-quiz-next]");
const contactForm = document.querySelector(".contact-form");
const projectCards = document.querySelectorAll(".project-card");
const projectGrid = document.querySelector("[data-project-grid]");
const projectShowMoreButton = document.querySelector("[data-project-show-more]");

const quizQuestions = [
  {
    title: "Какой сайт вам нужен?",
    description: "Выберите один вариант. Это поможет нам понять тип проекта и предложить подходящую структуру.",
    multiple: false,
    optionImages: [
      "./img/quiz-landing.png",
      "./img/quiz-corporate.png",
      "./img/quiz-catalog.png",
      "./img/quiz-internet-store.png",
      "./img/quiz-personal-account.png",
      "./img/quiz-consultation.png",
    ],
    options: [
      "Лендинг для одной услуги или продукта",
      "Корпоративный сайт компании",
      "Сайт-каталог",
      "Интернет-магазин",
      "Веб-сервис / личный кабинет",
      "Не знаю, нужна консультация",
    ],
  },
  {
    title: "На каком этапе сейчас проект?",
    description: "Выберите вариант, который лучше всего описывает текущую готовность проекта.",
    multiple: false,
    optionImages: [
      "./img/quiz-idea.png",
      "./img/quiz-structure.png",
      "./img/quiz-specs.png",
      "./img/quiz-design-mockup.png",
      "./img/quiz-redesign.png",
      "./img/quiz-from-scratch.png",
    ],
    options: [
      "Есть только идея",
      "Есть примерное понимание структуры",
      "Есть готовое техническое задание",
      "Есть дизайн-макет",
      "Уже есть сайт, нужно переделать",
      "Нужна разработка полностью с нуля",
    ],
  },
  {
    title: "Что должно быть на сайте?",
    description: "Можно выбрать несколько вариантов, если на сайте будет несколько ключевых разделов.",
    multiple: true,
    optionImages: [
      "./img/page-home.png",
      "./img/page-services.png",
      "./img/page-portfolio.png",
      "./img/page-catalog.png",
      "./img/page-blog.png",
      "./img/page-account.png",
      "./img/page-forms.png",
      "./img/page-quiz.png",
      "./img/page-payment.png",
      "./img/page-other.png",
    ],
    options: [
      "Главная страница",
      "Страницы услуг",
      "Портфолио / кейсы",
      "Каталог товаров или услуг",
      "Блог / статьи",
      "Личный кабинет",
      "Формы заявок",
      "Квиз",
      "Онлайн-оплата",
      "Другое",
    ],
  },
  {
    title: "Нужны ли интеграции с внешними сервисами?",
    description: "Можно выбрать несколько интеграций, если они должны работать одновременно.",
    multiple: true,
    optionImages: [
      "./img/integration-crm.png",
      "./img/integration-messages.png",
      "./img/integration-payment.png",
      "./img/integration-warehouse.png",
      "./img/integration-email.png",
      "./img/integration-analytics.png",
      "./img/integration-api.png",
      "./img/integration-unknown.png",
    ],
    options: [
      "CRM",
      "Telegram / WhatsApp-уведомления",
      "Онлайн-оплата",
      "Склад / учётная система",
      "Email-рассылки",
      "Аналитика и цели",
      "API других сервисов",
      "Пока не знаю",
    ],
  },
  {
    title: "Есть ли у вас готовые материалы для сайта?",
    description: "Можно выбрать все подходящие материалы и исходники, которые уже есть в наличии.",
    multiple: true,
    optionImages: [
      "./img/material-texts.png",
      "./img/material-photo-video.png",
      "./img/material-branding.png",
      "./img/material-structure.png",
      "./img/material-examples.png",
      "./img/material-start-from-scratch.png",
    ],
    options: [
      "Есть тексты",
      "Есть фото / видео",
      "Есть логотип и фирменный стиль",
      "Есть структура сайта",
      "Есть примеры сайтов, которые нравятся",
      "Ничего нет, нужна помощь с нуля",
    ],
  },
  {
    title: "Какой уровень дизайна вам нужен?",
    description: "Выберите стиль, который ближе к ожиданиям по визуалу и подаче.",
    multiple: false,
    optionImages: [
      "./img/design-minimal.png",
      "./img/design-corporate.png",
      "./img/design-premium.png",
      "./img/design-creative.png",
      "./img/design-animated.png",
      "./img/design-consultation.png",
      null,
    ],
    options: [
      "Минимальный и аккуратный",
      "Современный корпоративный",
      "Премиальный и дорогой",
      "Яркий креативный",
      "Сложный дизайн с анимациями",
      "Нужна консультация по стилю",
    ],
  },
  {
    title: "В какие сроки хотите запустить сайт?",
    description: "Выберите желаемый горизонт запуска или вариант без жёсткого дедлайна.",
    multiple: false,
    options: [
      "Как можно быстрее",
      "В течение 2–3 недель",
      "В течение 1 месяца",
      "В течение 2–3 месяцев",
      "Сроки не критичны",
      "Нужно сначала оценить объём работ",
    ],
  },
  {
    title: "Оставьте контакты",
    description: "Имя и телефон, чтобы отправить оценку и связаться с вами.",
    multiple: false,
    formStep: true,
  },
];

const quizState = {
  index: 0,
  furthestVisitedIndex: 0,
  answers: quizQuestions.map(() => new Set()),
};

let quizAdvanceTimer = null;

const clearQuizAdvanceTimer = () => {
  if (quizAdvanceTimer) {
    window.clearTimeout(quizAdvanceTimer);
    quizAdvanceTimer = null;
  }
};

const syncQuizSteps = () => {
  if (!quizSteps) {
    return;
  }

  const visualIndex = quizState.index;
  const canAdvanceOneMore = quizState.index < quizState.furthestVisitedIndex;

  quizSteps.querySelectorAll(".step").forEach((step, index) => {
    const hasAnswer = quizState.answers[index].size > 0;
    const isActive = index === visualIndex;
    const isComplete = index <= visualIndex;
    const isAnsweredRight =
      index > visualIndex &&
      (hasAnswer || (canAdvanceOneMore && index === quizState.index + 1));
    const isDisabled =
      index > quizState.index &&
      !hasAnswer &&
      !(canAdvanceOneMore && index === quizState.index + 1);

    step.classList.toggle("is-complete", isComplete);
    step.classList.toggle("is-active", isActive);
    step.classList.toggle("is-answered-right", isAnsweredRight);
    step.classList.toggle("is-disabled", isDisabled);
    step.setAttribute("aria-current", isActive ? "step" : "false");
    step.setAttribute("aria-disabled", String(isDisabled));
    step.disabled = isDisabled;
  });
};

const renderQuiz = () => {
  const question = quizQuestions[quizState.index];
  const selectedAnswers = quizState.answers[quizState.index];
  const isFinalStep = Boolean(question.formStep);

  quizInfo.textContent = `${isFinalStep ? "Шаг" : "Вопрос"} ${quizState.index + 1} из ${quizQuestions.length}`;
  quizTitle.textContent = question.title;
  quizDescription.textContent = question.description;

  syncQuizSteps();

  if (quizOptions) {
    quizOptions.classList.toggle("is-hidden", isFinalStep);
    if (!isFinalStep) {
      const hasOptionImages = Array.isArray(question.optionImages);
      quizOptions.innerHTML = question.options
        .map((option, index) => {
          const isSelected = selectedAnswers.has(option);
          const optionImage = question.optionImages?.[index];
          const imageMarkup = hasOptionImages
            ? optionImage
              ? `<span class="quiz-option__image"><img src="${optionImage}" alt="" aria-hidden="true" /></span>`
              : `<span class="quiz-option__image" aria-hidden="true"></span>`
            : "";
          const optionClass = hasOptionImages ? "quiz-option--text" : "quiz-option--plain";
          return `
            <button class="quiz-option ${optionClass}${isSelected ? " is-selected" : ""}" type="button" data-option-index="${index}" aria-pressed="${isSelected}">
              ${imageMarkup}
              <span class="quiz-option__title">${option}</span>
            </button>
          `;
        })
        .join("");
    } else {
      quizOptions.innerHTML = "";
    }
  }

  if (quizFinalForm) {
    quizFinalForm.classList.toggle("is-hidden", !isFinalStep);
  }

  if (quizBackButton) {
    quizBackButton.disabled = quizState.index === 0;
  }

  if (quizNextButton) {
    quizNextButton.textContent = isFinalStep ? "Отправить заявку →" : "Следующий вопрос →";
  }
};

const goToNextQuizStep = () => {
  clearQuizAdvanceTimer();

  if (quizState.index < quizQuestions.length - 1) {
    quizState.index += 1;
    quizState.furthestVisitedIndex = Math.max(quizState.furthestVisitedIndex, quizState.index);
    renderQuiz();
    return;
  }

  quizFinalForm?.requestSubmit();
};

const initProjectSliders = () => {
  projectCards.forEach((card) => {
    const slider = card.querySelector(".project-card__slider");
    const slides = Array.from(card.querySelectorAll(".project-card__slide"));
    const pagerDots = Array.from(card.querySelectorAll(".project-card__pager span"));
    const prevButton = card.querySelector(".project-card__arrow--prev");
    const nextButton = card.querySelector(".project-card__arrow--next");

    if (!slider || slides.length === 0) {
      return;
    }

    let currentIndex = 0;

    const syncSlider = () => {
      slider.style.transform = `translateX(-${currentIndex * 100}%)`;
      pagerDots.forEach((dot, index) => {
        dot.classList.toggle("is-active", index === currentIndex);
      });
    };

    prevButton?.addEventListener("click", () => {
      currentIndex = (currentIndex - 1 + slides.length) % slides.length;
      syncSlider();
    });

    nextButton?.addEventListener("click", () => {
      currentIndex = (currentIndex + 1) % slides.length;
      syncSlider();
    });

    syncSlider();
  });
};

const initProjectGrid = () => {
  if (!projectGrid || !projectShowMoreButton) {
    return;
  }

  const cards = Array.from(projectCards);
  const batchSize = 3;
  let visibleCount = Math.min(batchSize, cards.length);

  const syncGrid = () => {
    cards.forEach((card, index) => {
      card.classList.toggle("is-hidden", index >= visibleCount);
    });

    projectShowMoreButton.classList.toggle("is-hidden", visibleCount >= cards.length);
  };

  projectShowMoreButton.addEventListener("click", () => {
    visibleCount = Math.min(visibleCount + batchSize, cards.length);
    syncGrid();
  });

  syncGrid();
};

yearNodes.forEach((node) => {
  node.textContent = new Date().getFullYear();
});

menuBtn?.addEventListener("click", () => {
  const expanded = menuBtn.getAttribute("aria-expanded") === "true";
  menuBtn.setAttribute("aria-expanded", String(!expanded));
  nav?.classList.toggle("is-open");
});

nav?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    if (window.matchMedia("(max-width: 860px)").matches) {
      menuBtn?.setAttribute("aria-expanded", "false");
      nav.classList.remove("is-open");
    }
  });
});

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  },
  {
    threshold: 0.15,
  }
);

revealItems.forEach((item) => observer.observe(item));

accordionItems.forEach((item) => {
  const trigger = item.querySelector(".accordion-trigger");
  const panel = item.querySelector(".accordion-panel");

  trigger?.addEventListener("click", () => {
    const isOpen = item.classList.toggle("is-open");
    trigger.setAttribute("aria-expanded", String(isOpen));
    if (panel) {
      panel.hidden = !isOpen;
    }
  });
});

quizOptions?.addEventListener("click", (event) => {
  const optionButton = event.target.closest(".quiz-option");
  if (!optionButton) {
    return;
  }

  const currentQuestionIndex = quizState.index;
  const question = quizQuestions[currentQuestionIndex];
  const optionIndex = Number(optionButton.dataset.optionIndex);
  const optionValue = question.options[optionIndex];
  const selectedAnswers = quizState.answers[currentQuestionIndex];

  clearQuizAdvanceTimer();

  if (question.multiple) {
    if (selectedAnswers.has(optionValue)) {
      selectedAnswers.delete(optionValue);
      optionButton.classList.remove("is-selected");
      optionButton.setAttribute("aria-pressed", "false");
    } else {
      selectedAnswers.add(optionValue);
      optionButton.classList.add("is-selected");
      optionButton.setAttribute("aria-pressed", "true");
    }
    return;
  }

  selectedAnswers.clear();
  selectedAnswers.add(optionValue);
  renderQuiz();

  quizAdvanceTimer = window.setTimeout(() => {
    if (quizState.index === currentQuestionIndex) {
      goToNextQuizStep();
    }
  }, 260);
});

quizSteps?.addEventListener("click", (event) => {
  const stepButton = event.target.closest(".step");
  if (!stepButton) {
    return;
  }

  if (stepButton.disabled) {
    return;
  }

  const stepIndex = Number(stepButton.dataset.stepIndex);
  if (Number.isNaN(stepIndex)) {
    return;
  }

  clearQuizAdvanceTimer();
  quizState.index = stepIndex;
  quizState.furthestVisitedIndex = Math.max(quizState.furthestVisitedIndex, quizState.index);
  renderQuiz();
});

quizBackButton?.addEventListener("click", () => {
  clearQuizAdvanceTimer();

  if (quizState.index === 0) {
    return;
  }

  quizState.index -= 1;
  renderQuiz();
});

quizNextButton?.addEventListener("click", () => {
  goToNextQuizStep();
});

renderQuiz();
initProjectSliders();
initProjectGrid();

document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", (event) => {
    const targetId = anchor.getAttribute("href");
    if (!targetId || targetId === "#") {
      return;
    }

    const target = document.querySelector(targetId);
    if (!target) {
      return;
    }

    event.preventDefault();
    target.scrollIntoView({ behavior: "smooth", block: "start" });
  });
});

contactForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  const button = contactForm.querySelector("button");
  const originalText = button.textContent;

  button.disabled = true;
  button.textContent = "Заявка отправлена";

  window.setTimeout(() => {
    button.disabled = false;
    button.textContent = originalText;
    contactForm.reset();
  }, 1400);
});

quizFinalForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  const button = quizNextButton;
  if (!button) {
    return;
  }

  const originalText = button.textContent;
  button.disabled = true;
  button.textContent = "Заявка отправлена";
  quizState.answers[quizState.index].add("submitted");

  window.setTimeout(() => {
    button.disabled = false;
    button.textContent = originalText;
    quizFinalForm.reset();
  }, 1400);
});
